﻿using System.Runtime.Serialization;

namespace SilverlightTestBed
{
    /// <summary>
    /// DataContract that matches the type sent from the server. 
    /// Must be kept in sync with server project.
    /// </summary>
    [DataContract(Name = "ChatData", Namespace = "urn:rwb.badinfluencesoftware.com")]
    public class ChatData
    {
        [DataMember]
        public string IpAddress
        {
            get;
            set;
        }

        [DataMember]
        public string Data
        {
            get;
            set;
        }
    }
}
