﻿namespace SilverlightTestBed
{
    using System;
    using System.Linq;
    using System.Diagnostics;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using System.ServiceModel.Channels;
    using System.Runtime.Serialization;
    using System.Collections.ObjectModel;

    public partial class Page : UserControl
    {
        PushDataReceiver pusher;
        PushDataProcessor processor = new PushDataProcessor();
        ObservableCollection<ChatData> messages = new ObservableCollection<ChatData>();
        bool messagesUpdated;

        /// <summary>
        /// Initializes a new instance of the Page class, assigns the MessageBox ItemsSource, and attaches event listeners. 
        /// </summary>
        public Page()
        {
            InitializeComponent();

            this.messageBox.ItemsSource = this.messages;

            this.messageBox.LayoutUpdated += new EventHandler(messageBox_LayoutUpdated);
            this.Loaded += new RoutedEventHandler(Page_Loaded);
            this.processor.ProcessChatData += this.AddChatMessage;
        }

        void messageBox_LayoutUpdated(object sender, EventArgs e)
        {
            if (this.messagesUpdated)
            {
                // Scroll the message box to the newest chat message upon msg arrival.
                this.messageBox.ScrollIntoView(this.messageBox.Items[this.messageBox.Items.Count - 1]);
                this.messagesUpdated = false;
            }  
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            // Start PushDataReceiver.

            this.pusher = new PushDataReceiver(
                this.processor,
                "http://localhost.:49483/GameStreamService.svc",    
                // "http://www.YourDomain.com/GameStreamService.svc",

                // You need the www even for subdomains when you are using a shared hosting plan and select addresses
                // prefixed with www (as done with this sample).
                // "http://www.api.YourDomain.com/WcfPollingDuplex/GameStreamService.svc",    
                "Silverlight/IGameStreamService/InitiateDuplex",    // The Wcf function or action.
                "");

            try
            {
                this.pusher.Start();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());

                // Add the exception information as a chat message to help debugging.
                this.messages.Add(
                   new ChatData()
                   {
                       Data = "Could not connect to PollingDuplex Service." + Environment.NewLine + ex.ToString()
                   });
            }
        }

        /// <summary>
        /// Sends a ChatData to the ChatServer, to be broadcast to all listeners.
        /// </summary>
        /// <param name="dw">The chat message to be sent.</param>
        private void Send(ChatData chatMessage)
        {
            Message m = Message.CreateMessage(
                MessageVersion.Soap11,
                "Silverlight/IGameStreamService/SendMessage",
                chatMessage,
                new DataContractSerializer(typeof(ChatData)));

            this.pusher.Send(m);
        }

        private void AddChatMessage(ChatData receivedData)
        {
            this.messages.Add(receivedData);

            // Used to notify the messageBox.LayoutUpdated event listener to scroll to the newest message.
            this.messagesUpdated = true;    
        }

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            string msg = this.inputBox.Text.Trim();
            if (e.Key == Key.Enter && msg.Length > 0)
            {
                ChatData chatMessage = new ChatData() { Data = msg };
                this.Send(chatMessage);

                this.inputBox.Text = string.Empty;
            }
        }
    }
}
