﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace WcfPollingDuplex
{
    /// <summary>
    /// DataContract that matches the type sent from the client. 
    /// Must be kept in sync with client project.
    /// </summary>
    [DataContract(Name = "ChatData", Namespace = "urn:rwb.badinfluencesoftware.com")]
    public class ChatData
    {
        [DataMember]
        public string IpAddress
        {
            get;
            set;
        }

        [DataMember]
        public string Data
        {
            get;
            set;
        }
    }
}
