﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Channels;
using System.ServiceModel.Activation;

namespace WcfPollingDuplex
{
    // NOTE: If you change the interface name "IGameStreamClient" here, you must also update the reference to "IGameStreamClient" in Web.config.
    [ServiceContract]
    public interface IGameStreamClient
    {
        // Makes server calls asynchronous so it doesn't block other calls.
        // Occurs often when a client disconnects and the server needs to wait for a timeout to determine whether or not 
        // to remove that client from the static client list.
        [OperationContract(IsOneWay = true, AsyncPattern = true)]
        IAsyncResult BeginReceive(Message message, AsyncCallback callback, object state);

        void EndReceive(IAsyncResult result);
    }
}
