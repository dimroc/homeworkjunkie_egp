﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;
using System.ServiceModel.Channels;

namespace WcfPollingDuplex
{
    // CallbackContract tells Wcf that this will be a Duplex Service, and which functions are available.
    [ServiceContract(Namespace = "Silverlight", CallbackContract = typeof(IGameStreamClient), SessionMode = SessionMode.Required)]
    public interface IGameStreamService
    {
        [OperationContract(IsOneWay = true)]
        void InitiateDuplex(Message receivedMessage);

        [OperationContract(IsOneWay = true)]
        void SendMessage(Message message);
    }
}
