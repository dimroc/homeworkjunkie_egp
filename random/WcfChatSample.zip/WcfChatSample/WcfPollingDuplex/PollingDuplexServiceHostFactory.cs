﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Activation;
using System.ServiceModel;
using System.Diagnostics;
using System.ServiceModel.Channels;

namespace WcfPollingDuplex
{
    /// <summary>
    /// Class that ensures only one address of a certain scheme (ie: http://) is passed to CreateServiceHost.
    /// This is needed when hosting Wcf services on a shared hosting plan.
    /// </summary>
    public class PollingDuplexServiceHostFactory : ServiceHostFactory
    {
        public override ServiceHostBase CreateServiceHost(string constructorString, Uri[] baseAddresses)
        {
            // When hosting on a shared hosting plan, the default IIS configuration passes 2 addresses
            // to CreateServiceHost: http://www.yoururl.com and http://yoururl.com.
            //
            // You can only add ONE address of a certain scheme (ie: http://), so we just take the www address
            // which happens to the the second one.
            if (baseAddresses.Length > 1)
            {
                return new PollingDuplexServiceHost(baseAddresses[1]);
            }

            return new PollingDuplexServiceHost(baseAddresses);
        }
    }

    class PollingDuplexServiceHost : ServiceHost
    {
        public PollingDuplexServiceHost(params Uri[] addresses)
            : base(typeof(GameStreamService), addresses)
        {
        }

        /// <summary>
        /// Programmatically creates the Wcf PollingDuplexHttpBinding.
        /// </summary>
        protected override void InitializeRuntime()
        {
            PollingDuplexHttpBinding binding = new PollingDuplexHttpBinding();

            this.AddServiceEndpoint(
                typeof(IGameStreamService),
                new PollingDuplexHttpBinding(),
                "");

            base.InitializeRuntime();
        }
    }
}
