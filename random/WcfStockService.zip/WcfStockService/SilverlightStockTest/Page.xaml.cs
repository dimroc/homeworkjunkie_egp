﻿namespace SilverlightStockTest
{
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Windows.Controls;
    using System.Windows.Input;
    using SilverlightStockTest.YahooStockServiceReference;

    public partial class Page : UserControl
    {
        private StockQuoteServiceClient client;

        public Page()
        {
            this.InitializeComponent();

            this.client = new StockQuoteServiceClient();

            // Insert returned stock quotes into the listbox.
            this.client.GetQuoteCompleted += (o, e) => this.listBox.Items.Insert(0, e.Result);  
            this.client.GetQuotesCompleted += this.Client_GetQuotesCompleted;
        }

        private void Client_GetQuotesCompleted(object sender, GetQuotesCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                foreach (var item in e.Result)
                {
                    this.listBox.Items.Insert(0, item);
                }
            }
            else
            {
                throw e.Error;
            }
        }

        /// <summary>
        /// On Enter, submit the entered stock symbols to the web service.
        /// </summary>
        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                this.inputBox.Text = this.inputBox.Text.Trim();
                if (!string.IsNullOrEmpty(this.inputBox.Text))
                {
                    string input = this.inputBox.Text;
                    if (input.Contains(","))
                    {
                        // Split the comma separated values and submit them to the web service.
                        string[] tickers = input.Split(',');
                        ObservableCollection<string> collection = new ObservableCollection<string>();
                        foreach (string ticker in tickers)
                        {
                            collection.Add(ticker.Trim());
                        }

                        this.client.GetQuotesAsync(collection);
                    }
                    else
                    {
                        // Send the one ticker symbol to the web service.
                        this.client.GetQuoteAsync(this.inputBox.Text);
                    }

                    this.inputBox.Text = string.Empty;
                }
            }
        }
    }
}