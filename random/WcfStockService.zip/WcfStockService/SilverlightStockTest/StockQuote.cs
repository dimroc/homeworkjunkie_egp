﻿namespace SilverlightStockTest.YahooStockServiceReference
{
    /// <summary>
    /// Adds fields to the auto-generated StockQuote struct (from the Service Reference)
    /// for easier binding from Xaml. 
    /// (I don't think Silverlight supports Binding Paths that index.)
    /// </summary>
    public partial struct StockQuote
    {
        public double Range52wkLow
        {
            get { return this.Range52wk[0]; }
        }

        public double Range52wkHigh
        {
            get { return this.Range52wk[1]; }
        }
    }
}
