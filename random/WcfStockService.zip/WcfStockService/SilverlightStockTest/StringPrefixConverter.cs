﻿namespace SilverlightStockTest
{
    using System;
    using System.Windows.Data;

    /// <summary>
    /// Returns a string with the parameter prefixed to the passed value.
    /// </summary>
    public class StringPrefixConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value != null && parameter != null)
            {
                return parameter.ToString() + value.ToString();
            }
            else if (value != null)
            {
                return value.ToString();
            }

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
