﻿namespace WcfStockService
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Text.RegularExpressions;
    using System.Web;

    /// <summary>
    /// Utility functions to gather and parse values from an html string, such as the entire page content.
    /// </summary>
    public static class HtmlScraper
    {
        public static string GetPageContent(string url)
        {
            WebRequest wreq = HttpWebRequest.Create(url);
            WebResponse wres = wreq.GetResponse();
            StreamReader sr = new StreamReader(wres.GetResponseStream());
            string content = sr.ReadToEnd();
            sr.Close();

            return content;
        }

        public static string ParseContent(string page, Regex prefix, string endtag)
        {
            Match m = prefix.Match(page);
            if (m.Success)
            {
                page = page.Substring(m.Index + m.Value.Length);
                int i = page.IndexOf(endtag);
                page = page.Substring(0, i);

                return page;
            }

            return null;
        }
    }
}
