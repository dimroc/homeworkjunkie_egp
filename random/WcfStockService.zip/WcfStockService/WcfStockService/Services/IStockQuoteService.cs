﻿namespace WcfStockService
{
    using System.Collections.Generic;
    using System.ServiceModel;

    /// <summary>
    /// The services offered by the Poor Man's Stock Quote Web Service!
    /// </summary>
    [ServiceContract]
    public interface IStockQuoteService
    {
        [OperationContract]
        StockQuote GetQuote(string ticker);

        [OperationContract]
        List<StockQuote> GetQuotes(string[] tickers);
    }
}
