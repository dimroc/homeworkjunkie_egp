﻿namespace WcfStockService
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;

    /// <summary>
    /// The StockQuote information. I often lazily return -1 on failure (bad I know).
    /// </summary>
    [DataContract]
    public struct StockQuote
    {
        [DataMember]
        public string Symbol
        {
            get;
            set;
        }

        [DataMember]
        public string CompanyName
        {
            get;
            set;
        }

        [DataMember]
        public double Price
        {
            get;
            set;
        }

        [DataMember]
        public long Volume
        {
            get;
            set;
        }

        [DataMember]
        public double Change
        {
            get;
            set;
        }

        [DataMember]
        public double MarketCapital
        {
            get;
            set;
        }

        [DataMember]
        public List<double> Range52wk
        {
            get;
            set;
        }
    }
}
