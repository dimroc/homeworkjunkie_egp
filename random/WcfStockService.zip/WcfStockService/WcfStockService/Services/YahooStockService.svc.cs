﻿namespace WcfStockService
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.ServiceModel;
    using System.Text;
    using System.Text.RegularExpressions;

    /// <summary>
    /// The Stock Quote Web Service that scrapes values from Yahoo's finance stock page.
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public class YahooStockService : IStockQuoteService
    {
        public const string UrlPrefix = "http://finance.yahoo.com/q?s=";

        /// <summary>
        /// Gets Stock Quote information by checking for the passed in ticker symbol.
        /// </summary>
        /// <param name="ticker">The ticker symbol to check for: ie GOOG, MSFT, GE.</param>
        /// <returns></returns>
        public StockQuote GetQuote(string ticker)
        {
            string stockUrl = UrlPrefix + ticker;
            string page = HtmlScraper.GetPageContent(stockUrl);

            StockQuote sq = new StockQuote();
            sq.Symbol = ticker.ToUpper();
            sq.CompanyName = this.ParseCompanyName(page);
            sq.Price = this.ParsePrice(page);
            sq.Volume = this.ParseVolume(page);
            sq.Change = this.ParseChange(page);
            sq.MarketCapital = this.ParseMarketCapital(page);
            sq.Range52wk = this.Parse52wkRange(page);

            return sq;
        }        

        public List<StockQuote> GetQuotes(string[] tickers)
        {
            List<StockQuote> quotes = new List<StockQuote>();
            foreach (string ticker in tickers)
            {
                quotes.Add(this.GetQuote(ticker));
            }

            return quotes;
        }

        private List<double> Parse52wkRange(string page)
        {
            List<double> range = new List<double>() { -1, -1 };
            Regex parseFor = new Regex(
                Regex.Escape("52wk Range:</td><td class=\"yfnc_tabledata1\">"));
            string part = HtmlScraper.ParseContent(page, parseFor, "</td>");

            if (part == null)
            {
                return range;
            }
            
            string[] parts = part.Split('-');
            try
            {
                range[0] = double.Parse(parts[0].Replace(",", ""));
                range[1] = double.Parse(parts[1].Replace(",", ""));
                return range;
            }
            catch
            {
                return range;
            }
        }

        private double ParseMarketCapital(string page)
        {
            Regex parseFor = new Regex(
                Regex.Escape("Market Cap:</td><td class=\"yfnc_tabledata1\">"));
            string part = HtmlScraper.ParseContent(page, parseFor, "</td>");
            if (!string.IsNullOrEmpty(part))
            {
                part = part.Replace(",", "");
                double multiplier = 1;
                if (part.EndsWith("B"))
                {
                    multiplier = 1000000000;
                }
                else if (part.EndsWith("M"))
                {
                    multiplier = 1000000;
                }
                else
                {
                    throw new InvalidOperationException("The market capital must end with either B (billion) or M (million).");
                }

                part = part.Remove(part.Length - 1);
                return double.Parse(part) * multiplier;
            }

            return -1;
        }

        private double ParseChange(string page)
        {
            double multiplier = 1;

            Regex parseForProfit = new Regex(
                "Change:</td><td class=\"yfnc_tabledata1\"><img width=\"10\" height=\"14\" border=\"0\" src=\"http://us.i1.yimg.com/us.yimg.com/i/us/fi/03rd/[\\w]+_g.gif\" alt=\"[\\w]+\"> <b style=\"color:#[a-zA-Z0-9]+;\">");
            string part = HtmlScraper.ParseContent(page, parseForProfit, "</b>");
            
            if (string.IsNullOrEmpty(part))
            {
                Regex parseForLoss = new Regex(
                    "Change:</td><td class=\"yfnc_tabledata1\"><img width=\"10\" height=\"14\" border=\"0\" src=\"http://us.i1.yimg.com/us.yimg.com/i/us/fi/03rd/down_r.gif\" alt=\"Down\"> <b style=\"color:#cc0000;\">");
                part = HtmlScraper.ParseContent(page, parseForLoss, "</b>");
                multiplier = -1;
            }

            if (!string.IsNullOrEmpty(part))
            {
                part = part.Replace(",", "");
                return double.Parse(part) * multiplier;
            }

            return -1;
        }

        private long ParseVolume(string page)
        {
            Regex parseFor = new Regex(Regex.Escape("Volume:</td><td class=\"yfnc_tabledata1\">"));
            string part = HtmlScraper.ParseContent(page, parseFor, "</td>");
            if (!string.IsNullOrEmpty(part))
            {
                part = part.Replace(",", "");
                return long.Parse(part);
            }

            return -1;
        }

        private string ParseCompanyName(string page)
        {
            Regex parseFor = new Regex("<div class=\"yfi_quote_summary\"><div class=\"hd\"><h1>");
            return HtmlScraper.ParseContent(page, parseFor, "</h1>");
        }        

        private double ParsePrice(string page)
        {            
            Regex parseFor = new Regex(Regex.Escape("<div id=\"yfi_investing_head\"><div><small>") + "[\\w: ]+" + Regex.Escape("</small><big><b>"));
            string part = HtmlScraper.ParseContent(page, parseFor, "</b>");
            if (!string.IsNullOrEmpty(part))
            {
                part = part.Replace(",", "");
                return double.Parse(part);
            }

            return -1;
        }
    }
}
